roslaunch cloud_to_map cloud_to_map.launch 

rosrun map_server map_saver -f mymap

